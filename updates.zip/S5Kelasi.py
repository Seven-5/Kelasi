# kels.py
import tkinter as tk
from tkinter import messagebox, filedialog
import datetime
import json
import os
import base64
from lib import hardware_info
from lib import license_crypto
from lib import storage
import subprocess as sp
import subprocess
import sys
import time
import shutil
import winreg
import ctypes
from PIL import Image, ImageTk
import win32com.client

import pythoncom
import win32com.client

import psutil


DEFAULT_TRIAL_DAYS = 60
PROGRAMME = "S5Kelasi.exe"

SECURE_SESSION_FILE= os.path.join(os.getenv("APPDATA"), ".FrOSE", "WINDOWS_SEMENA.dll")

SECURE_SESSION_DIR= os.path.join(os.getenv("APPDATA"), ".FrOSE")

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))


SESSION_FILE = os.path.join(BASE_DIR, "ndkasdem","riseloma","WKHhllwjjoohgkkoit54gEQlkjkfs.txt")
SECURE_DIR = os.path.join(BASE_DIR, "ndkasdem","riseloma","secure_storage")
SECURE_FILENAME = "hdS2Nhs4Fl.exe"
PROTECTED_NAME = "hgKPl4Li8aO.dll"
DATA_WORKS =  os.path.join(BASE_DIR, "ndkasdem","riseloma")
exe_file = os.path.join(BASE_DIR, "ndkasdem", "kelassLibs.exe")
log_path = os.path.join(BASE_DIR, "kelasi.log")

def log(msg):
    print(msg)
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {msg}\n")
    except Exception as e:
        print(f"Erreur lors de l'écriture dans le log: {e}")

class ClientLicenseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestion de Licence - Client")

        # 1. Chargement de la licence existante (registre ou fichier)
        self.license_data = storage.load_license_from_registry() or storage.load_license_from_file() or storage._load_license_from_db()
        #log(f"License Data: {self.license_data}")
        # 2. Si licence « active » ou « evaluation » et pas expirée
        if self.license_data and self.license_data.get("license_type") in ("active", "evaluation"):
            try:
                exp = datetime.datetime.fromisoformat(self.license_data.get("expiration"))
                if datetime.datetime.now() <= exp:
                    #log("# licence valide : lance le programme principal et quitte la fenêtre")
                    self.launch_main_program()
                    root.destroy()
                    return
            except Exception:
                #log("# en cas de format de date incorrect, on retombe sur l'affichage de l'UI")
                pass

        #log("# 3. Sinon on affiche les widgets d'activation")
        self.create_widgets()

    def create_widgets(self):


        tk.Button(self.root, text="Charger le fichier de licence", command=self.load_licence).pack(pady=5)

        self.tab_frame = tk.Frame(self.root)
        self.tab_frame.pack(padx=10, pady=10)
        
       
        self.set_window_icon(self.root)
        # Onglet Empreinte
        self.fingerlog_frame = tk.LabelFrame(self.tab_frame, text="Empreinte Machine")
        self.fingerlog_frame.pack(fill="both", padx=5, pady=5)

        tk.Label(self.fingerlog_frame, text="Votre clé unique grâce à la quelle vous recevrez la clé de licence").pack(anchor="w")

        self.fingerlog_text = tk.Text(self.fingerlog_frame, height=2, width=60)
        self.fingerlog_text.pack(pady=5)
        self.fingerlog_text.insert(tk.END, hardware_info.get_machine_fingerprint())

        tk.Label(self.fingerlog_frame, text="Numéro de serie !").pack(anchor="w")

        self.cle_de_serie_text = tk.Text(self.fingerlog_frame, height=2, width=60)
        self.cle_de_serie_text.pack(pady=5)

        #tk.Button(self.fingerlog_frame, text="Rafraîchir", command=self.refresh_fingerlog).pack(pady=5)

        # Onglet Activation
        self.activate_frame = tk.LabelFrame(self.tab_frame, text="Activation de Licence")
        self.activate_frame.pack(fill="both", padx=5, pady=5)

        tk.Label(self.activate_frame, text="Type de licence").pack(anchor="w")
        self.entry_type = tk.Entry(self.activate_frame)
        #self.entry_type.insert(0, "active")
        self.entry_type.pack(pady=2)

        tk.Label(self.activate_frame, text="Date d'expiration").pack(anchor="w")
        self.entry_expiration = tk.Entry(self.activate_frame)
        trial_expiration = (datetime.datetime.now() + datetime.timedelta(days=DEFAULT_TRIAL_DAYS)).date().isoformat()
        #self.entry_expiration.insert(0, trial_expiration)
        self.entry_expiration.pack(pady=2)

        tk.Label(self.activate_frame, text="Clé de Licence :").pack(anchor="w")
        self.entry_signature = tk.Text(self.activate_frame, height=4, width=60)
        self.entry_signature.pack(pady=5)

        tk.Button(self.activate_frame, text="Activer Maintenant", command=self.activate_license).pack(pady=5)

        # Bouton lancement programme principal
        tk.Button(self.root, text="Continuer l'évaluation", command=self.continue_evaluation).pack(pady=10)

    def refresh_fingerlog(self):
        fingerprint = hardware_info.get_machine_fingerprint()
        self.fingerlog_text.delete("1.0", tk.END)
        #self.fingerlog_text.insert(tk.END, fingerprint)

    def activate_license(self):
        fingerprint = hardware_info.get_machine_fingerprint()
        license_type = self.entry_type.get().strip()
        expiration = self.entry_expiration.get().strip()
        license_signature = self.entry_signature.get("1.0", tk.END).strip()
        id_client = self.cle_de_serie_text.get("1.0", tk.END).strip()

        if not license_signature:
            messagebox.showerror("Erreur", "Veuillez saisir la signature de licence.")
            return
        idmac = fingerprint
       
        if idmac != id_client and license_type !="trial":
            messagebox.showerror("Erreur", "Numéro de série incorecte !")
            return
        valid = license_crypto.verify_license(id_client, expiration, license_signature)
        if valid:
            self.license_data = {
                "license_type": license_type,
                "fingerprint": fingerprint,
                "expiration": expiration,
                "signature": license_signature,
                "last_run": datetime.datetime.now().isoformat(),
            }
            storage.update_license_backups(self.license_data)
            messagebox.showinfo("Activation", "Licence activée avec succès !")
            self.root.destroy()
            create_session()
            decode_dictionary_cache()

            sp.run([exe_file])
            
            secure_copy_hdS2Nhs4Fl()
            
            delete_session()
            sys.exit()

        else:
            messagebox.showerror("Activation", "Licence invalide ou expirée.")
    def load_licence(self):
        path = filedialog.askopenfilename(filetypes=[("Fichier de Licence", "*.lic")])
        if path:
            try:
                with open(path, "r+") as f:
                    data = json.load(f)
                    if not all(k in data for k in ("license_type", "expiration", "signature", "fingerprint")):
                        raise ValueError("Le fichier de licence est incomplet ou corrompu.")
                   
                    
                    self.cle_de_serie_text.delete("1.0", tk.END)
                    self.cle_de_serie_text.insert(tk.END, data["fingerprint"])

                    self.entry_type.delete(0, tk.END)
                    self.entry_type.insert(tk.END, data["license_type"])
                    self.entry_expiration.delete(0, tk.END)
                    self.entry_expiration.insert(tk.END, data["expiration"])
                    self.entry_signature.delete("1.0", tk.END)
                    self.entry_signature.insert(tk.END, data["signature"])
                messagebox.showinfo("Clé de licence", "Clé de licence chargée avec succès.")
            except Exception as e:
                messagebox.showerror("Erreur", f"Impossible de charger la clé : {e}")
    def is_trial_valid(self):
        """
        Vérifie la validité du mode trial :
          1) Si la date système a reculé sous last_run → block.
          2) Si la date courante > expiration → block.
          3) Sinon → valide, on met à jour last_run.
        """
        lic = self.license_data
        now = datetime.datetime.now()

        # 1) Si pas de licence du tout, on initialise un trial
        if not lic:
            #log("initialisation d'un essai")
            self.create_trial_license()
            lic = self.license_data

        # 2) Vérification recul d'horloge (si last_run existait)
        last = lic.get("last_run")
        if last:
            try:
                last_dt = datetime.datetime.fromisoformat(last)
                if now < last_dt:
                    messagebox.showerror("Erreur", "Date système antérieure au dernier lancement !")
                    return False
            except Exception:
                # En cas de mauvais format de last_run, on le réinitialise plus bas
                pass

        # 3) Vérification expiration trial
        try:
            exp = datetime.datetime.fromisoformat(lic.get("expiration"))
        except Exception:
            messagebox.showerror("Erreur", "Format de date d'expiration invalide !")
            return False

        if now > exp:
            messagebox.showerror("Période d'essai expirée", 
                                 f"Votre essai s'est terminé le {exp.date().isoformat()}.")
            return False

        # 4) Tout est OK → on met à jour last_run et on persiste
        lic["last_run"] = now.isoformat()
        storage.update_license_backups(lic)
        return True


    def continue_evaluation(self):
        """
        Bouton « Continuer l'évaluation » : on ne lance le programme principal
        que si is_trial_valid() renvoie True.
        """
        if not self.is_trial_valid():
            #log("# Ne rien faire si la période d'essai est invalide")
            messagebox.showerror("Période d'essai expirée", 
                                 f"Votre essai s'est terminé.")
            return


        # Tout va bien → on ferme la fenêtre et on démarre le main
        self.root.destroy()
        create_session()
        decode_dictionary_cache()

        sp.run([exe_file])
        
        secure_copy_hdS2Nhs4Fl()
        delete_session()
        sys.exit()

    def create_trial_license(self):
        self.license_data = {
            "license_type": "trial",
            "fingerprint": hardware_info.get_machine_fingerprint(),
            "trial_start": datetime.datetime.now().isoformat(),
            "last_run": datetime.datetime.now().isoformat(),
            "expiration": (datetime.datetime.now() + datetime.timedelta(days=DEFAULT_TRIAL_DAYS)).date().isoformat(),
        }

        storage.update_license_backups(self.license_data)
      

   

    def set_window_icon(self, window):
        try:
            img = Image.open(os.path.join(BASE_DIR,"ndkasdem","riseloma","Bilili","kelasi.png"))
            photo = ImageTk.PhotoImage(img)
            window.tk.call('wm', 'iconphoto', window._w, photo)
        except Exception as e:
            log("Erreur lors de l'ajout de l'icône :", e)




def secure_copy_hdS2Nhs4Fl():
    """
    Copie le fichier hdS2Nhs4Fl.exe depuis le dossier de destination vers le dossier sécurisé.
    """
    target_dir = os.path.join(BASE_DIR,"ndkasdem","riseloma")
    source_path = os.path.join(target_dir, SECURE_FILENAME)
    #log(source_path)
    if os.path.exists(source_path):
        if not os.path.exists(SECURE_DIR):
            os.makedirs(SECURE_DIR)
        secure_path = os.path.join(SECURE_DIR, SECURE_FILENAME)
        with open(source_path, "rb") as src, open(secure_path, "wb") as dst:
            dst.write(src.read())
    

def copy_database():
    """
    P
    """
    cache_dir = "oliganopes"
    target_dir = os.path.join(BASE_DIR,"ndkasdem","riseloma")
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    
   
    src_path = os.path.join(cache_dir, SECURE_FILENAME)
    if os.path.isfile(src_path):
        dest_db = os.path.join(target_dir, SECURE_FILENAME)
        if not os.path.exists(dest_db):
            dest_path = os.path.join(target_dir, SECURE_FILENAME)
            with open(dest_path, "rb") as src, open(dest_db, "wb") as dst:
                dst.write(src.read()) 

def create_session():
    """
    1. Crée le fichier de session avec une clé fixe.
    2. Liste le dossier "oliganopes" et, pour chaque fichier (uniquement les fichiers),
       encode son contenu en Base64 et crée une copie dans le dossier "DictionaryCache"
       avec le même nom.
    """
    session_dir = os.path.dirname(SESSION_FILE)
    if not os.path.exists(session_dir):
        os.makedirs(session_dir)
    
    # Création du fichier de session avec une clé fixe
    with open(SESSION_FILE, "w") as f:
        f.write("ZkdR455GksLeog8746dsJKF55GgJQU")


    


def decode_dictionary_cache():
    """
    Parcourt DictionaryCache, décode en Base64 et écrit dans ndkasdem/riseloma.
    En version d’essai : tous les fichiers sauf 'hgKPl4Li8aO.dll' sont copiés.
    En version activée : tous les fichiers sont copiés.
    """

    # Définir les chemins
    SECURE_NAME = "hgKPl4Li8aO.dll"
    TARGET_DIR = os.path.join(BASE_DIR, "ndkasdem", "riseloma")
    CACHE_DIR = os.path.join(BASE_DIR, "DictionaryCache")

    # Charger la licence
    lic = storage.load_license_from_registry() or storage.load_license_from_file() or storage._load_license_from_db()
    if not lic:
        #log("[ERROR] Licence introuvable!")
        
        if os.path.exists(SESSION_FILE):
            try:
                os.remove(SESSION_FILE)
                #log(f"[OK] Session supprimée : {SESSION_FILE}")
            except Exception as e:
                log(f"[WARN] Impossible de supprimer la session : {e}")
        sys.exit()
    # Type de licence
    is_trial = lic.get("license_type", "").lower() == "trial"
    os.makedirs(TARGET_DIR, exist_ok=True)

    for fname in os.listdir(CACHE_DIR):
        if is_trial and fname == SECURE_NAME:
            #log(f"[INFO] {fname} ignoré (version d'essai)")
            continue

        src = os.path.join(CACHE_DIR, fname)
        if not os.path.isfile(src):
            continue

        try:
            with open(src, "rb") as f:
                raw = f.read()
                data = base64.b64decode(raw)
        except Exception as e:
            log(f"[WARN] Échec décodage {fname}: {e}")
            continue

        dst = os.path.join(TARGET_DIR, fname)
        with open(dst, "wb") as out:
            out.write(data)
        #log(f"[OK] Fichier décodé : {fname}")

    # Vérification si on doit copier le fichier sécurisé
    if not is_trial:
        secure_dll = os.path.join(SECURE_DIR, SECURE_NAME)
        target_dll = os.path.join(TARGET_DIR, SECURE_NAME)

        if not os.path.exists(target_dll):
            if os.path.exists(secure_dll):
                with open(secure_dll, "rb") as src, open(target_dll, "wb") as dst:
                    dst.write(src.read())
                #log(f"[OK] Copie de {SECURE_NAME} depuis le dossier sécurisé.")
            #else:
                #log(f"[ERROR] Fichier sécurisé manquant : {secure_dll}")




def delete_session():
    """
    1) Supprime le fichier de session.
    2) Dans CACHE_DIR, pour chaque fichier :
       - Sauvegarde toujours SECURE_FILENAME dans secure_dir_path (jamais supprimé).
       - Si licence trial : garde aussi PROTECTED_NAME, supprime les autres.
       - Si licence full  : supprime tout sauf SECURE_FILENAME.
    """
    # Constantes globales (définies en haut du module)
    #   SECURE_DIR  = "secure_storage"
    #   SECURE_FILENAME = "hdS2Nhs4Fl.exe"
    #   PROTECTED_NAME  = "hgKPl4Li8aO.dll"
    global BASE_DIR, SECURE_DIR, SECURE_FILENAME, PROTECTED_NAME

    CACHE_DIR       = os.path.join(BASE_DIR, "ndkasdem", "riseloma")
    secure_dir_path = os.path.join(BASE_DIR, SECURE_DIR)   # chemin final du dossier de backup

    # 1) Charger la licence
    lic = storage.load_license_from_registry() or storage.load_license_from_file() or storage._load_license_from_db()
    if not lic:
        #log("[ERROR] Licence introuvable, suppression annulée.")
        return

    is_trial = lic.get("license_type", "").lower() == "trial"

    # 2) Supprimer le fichier de session
    if os.path.exists(SESSION_FILE):
        try:
            os.remove(SESSION_FILE)
            #log(f"[OK] Session supprimée : {SESSION_FILE}")
        except Exception as e:
            log(f"[WARN] Impossible de supprimer la session : {e}")



    # 3) Vider CACHE_DIR
    if not os.path.isdir(CACHE_DIR):
        #log(f"[INFO] Dossier introuvable : {CACHE_DIR}")
        return

    for fname in os.listdir(CACHE_DIR):
        src_path = os.path.join(CACHE_DIR, fname)
        if not os.path.isfile(src_path):
            continue

        # 3a) Sauvegarde de SECURE_FILENAME (jamais supprimé)
        if fname == SECURE_FILENAME:
            os.makedirs(secure_dir_path, exist_ok=True)
            backup = os.path.join(secure_dir_path, SECURE_FILENAME)
            try:
                shutil.copy2(src_path, backup)
                #log(f"[OK] Backup de {SECURE_FILENAME} dans {secure_dir_path}")
            except Exception as e:
                log(f"[WARN] Échec du backup de {SECURE_FILENAME} : {e}")
            continue

        # 3b) Si trial, on conserve aussi PROTECTED_NAME
        if is_trial and fname == PROTECTED_NAME:
            #log(f"[INFO] Conservation en trial : {PROTECTED_NAME}")
            continue

        # 3c) Sinon, suppression
        try:
            os.remove(src_path)
            #log(f"[OK] Supprimé : {fname}")
        except Exception as e:
            log(f"[WARN] Impossible de supprimer {fname} : {e}")


LIC_PATH = os.path.join(BASE_DIR, "oliganopes", "Licence.lic")       
def began_trial():

    
    if not os.path.exists(LIC_PATH):
        return

    
    try:
        with open(LIC_PATH, "r", encoding="utf-8") as f:
            temp_lic = json.load(f)

        expiration  = temp_lic.get("expiration")
        signature   = temp_lic.get("signature")
        # ancienne clé dans le .lic, qu'on utilise juste pour la vérif
        temp_fp     = temp_lic.get("fingerprint", "")
        real_fp     = hardware_info.get_machine_fingerprint()
        now_iso     = datetime.datetime.now().isoformat()

        if expiration and signature and license_crypto.verify_license(temp_fp, expiration, signature):
            # on remet la vraie empreinte
            #temp_lic["fingerprint"]  = real_fp
            # on initialise last_run pour le trial
            temp_lic["last_run"]   = now_iso
            # (optionnel) on peut aussi stocker trial_start si besoin
            temp_lic.setdefault("trial_start", now_iso)

            #log("Licence de version d'essai valide. Mise à jour des backups.")
            storage.update_license_backups(temp_lic)

            os.remove(LIC_PATH)
            #log("Fichier de licence temporaire supprimé.")
        #else:
            #log("Licence dans oliganopes/Licence.lic invalide ou expirée.")

    except Exception as e:
        log(f"Erreur lors de la vérification de la licence temporaire : {e}")


import sys, os, ctypes, subprocess, winreg, pythoncom, win32com.client

TASK_NAME     = "S5Kelasi_Launcher"
FLAG_REG_PATH = r"Software\Seven5KELASI\Settings"
FLAG_NAME     = "FirstRunCompleted"


# ─── Entrée du programme ───────────────────────────────────────────────────


def is_admin(): 
    return ctypes.windll.shell32.IsUserAnAdmin() != 0

def task_exists() -> bool:
    return subprocess.run(
        f'schtasks /Query /TN "{TASK_NAME}"',
        shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    ).returncode == 0

def create_scheduled_task():
    cmd = f'schtasks /Create /SC ONLOGON /RL HIGHEST /TN "{TASK_NAME}" /TR "\\"{sys.executable}\\"" /F'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    success = result.returncode == 0
    
    if not success:
        log("Erreur : " + result.stderr.strip())
    return success
def create_task():
    """
    Crée une tâche ONDEMAND sous SYSTEM. Doit être appelé en mode admin.
    """
    if task_exists():
        return

    exe = sys.executable  # pointe vers ton kels.exe PyInstaller one-file

    args = [
        "schtasks",
        "/Create",
        "/TN", TASK_NAME,
        "/TR", exe,
        "/SC", "ONDEMAND",
        "/RL", "HIGHEST",
        "/RU", "SYSTEM",
        "/F"
    ]
    try:
        # shell=False par défaut, on passe la liste
        subprocess.run(args, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        #log(f"❌ Échec de la création de la tâche planifiée :")
        #log(f"  stdout: {e.stdout}")
        #log(f"  stderr: { e.stderr}")
        sys.exit(1)


def run_task_via_com():
    """Lance la tâche existante en contexte SYSTEM, sans UAC."""
    pythoncom.CoInitialize()
    scheduler  = win32com.client.Dispatch("Schedule.Service")
    scheduler.Connect()
    root       = scheduler.GetFolder("\\")
    task       = root.GetTask(TASK_NAME)
    task.Run("")  # on peut passer une string d’arguments ou ""  
    sys.exit(0)

def elevate_for_setup():
    """Relance CE MÊME EXE en admin, avec --setup-task."""
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas",
        sys.executable,
        "--setup-task",
        None, 1
    )


def is_already():
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['name']== PROGRAMME and proc.info['pid'] != os.getpid():
                return True
        except(psutil.NoSuchProcess, psutil.AccessDenied):
            continue

def main_app_logic():
    try:
        #log("[INFO] Démarrage de l'application...")

        # éviter double-lancement
        nbr_data = os.listdir(DATA_WORKS)

        if is_already():
            #log("[WARN] Session déjà active ou données excessives. Fermeture.")
            sys.exit()

        # Charger la licence
        license_data = (
            storage.load_license_from_registry()
            or storage.load_license_from_file()
            or storage._load_license_from_db()
        )
        #log(f"[INFO] Données licence récupérées : {license_data}")

        is_valid = False
        if license_data:
            try:
                last_run = datetime.datetime.fromisoformat(license_data.get("last_run"))
                if datetime.datetime.now() >= last_run:
                    is_valid = True
            except Exception as e:
                log(f"[ERROR] Erreur lors de la vérification de la date : {e}")

        if is_valid and license_data.get("license_type") in ("active", "evaluation"):
            # Licence valide
            create_session()
            #log("[INFO] Session créée avec succès.")

            root = tk.Tk()
            app = ClientLicenseApp(root)
            #log("[INFO] Interface principale chargée.")
            
            root.destroy()

            decode_dictionary_cache()

            log(f"[INFO] Lancement de l'exécutable : {exe_file}")
            sp.run([exe_file])

            secure_copy_hdS2Nhs4Fl()
            delete_session()
            log("[INFO] Session supprimée. Fermeture.")
            sys.exit()

        else:
            # Licence non valide
            root = tk.Tk()
            app = ClientLicenseApp(root)
            #log("[INFO] Affichage de l'interface pour gestion licence.")
            root.mainloop()

            # Nettoyage de session après fermeture
            if os.path.exists(SESSION_FILE):
                try:
                    os.remove(SESSION_FILE)
                    #log(f"[OK] Session supprimée : {SESSION_FILE}")
                except Exception as e:
                    log(f"[WARN] Impossible de supprimer la session : {e}")
            sys.exit()

    except Exception as e:
        log(f"[FATAL] Erreur inattendue : {e}")
        #log(traceback.format_exc())  # Log tous les détails de l'erreur
        sys.exit(1)

# ─── Entrée du programme ───────────────────────────────────────────────────
if __name__ == "__main__":
# 1) Si lancé avec --setup-task, on est en admin demandé par elevate_for_setup()
    

    if not is_admin():

        elevate_for_setup()
        sys.exit()

    main_app_logic()
    """if "--setup-task" in sys.argv:
                    if not is_admin():
                        print("⚠️ Vous devez être admin pour créer la tâche planifiée.")
                        sys.exit(1)
                    create_scheduled_task()
                    # on peut poser le flag dans le registre pour marquer le setup fait
                    key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, FLAG_REG_PATH)
                    winreg.SetValueEx(key, FLAG_NAME, 0, winreg.REG_DWORD, 1)
                    winreg.CloseKey(key)
                    
            
                # 2) Si l’utilisateur double-clic en standard
                if not is_admin():
                    # 2a) première fois ? on élève pour créer la tâche
                    if not task_exists():
                        elevate_for_setup()
                    else:
                        # 2b) sinon, on lance la tâche SYSTEM (sans UAC)
                        run_task_via_com()
                    sys.exit(0)
            
            
                # 3) Ici, on est admin (ou la tâche SYSTEM a démarré l’exe)
                main_app_logic()"""