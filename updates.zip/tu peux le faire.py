def decode_dictionary_cache():
    """
    Parcourt DictionaryCache, décode en Base64 et écrit dans ndkasdem/riseloma.
    En version d’essai : tous les fichiers sauf 'hgKPl4Li8aO.dll' sont copiés.
    En version activée : tous les fichiers sont copiés.
    """

    # Définir les chemins
    SECURE_NAME = "hgKPl4Li8aO.dll"
    TARGET_DIR = os.path.join(BASE_DIR, "ndkasdem", "riseloma")
    CACHE_DIR = os.path.join(BASE_DIR, "DictionaryCache")

    # Charger la licence
    lic = ClientLicenseApp.load_license_from_registry() or ClientLicenseApp.load_license_from_file() or ClientLicenseApp._load_license_from_db()
    if not lic:
        #print("[ERROR] Licence introuvable!")
        
        if os.path.exists(SESSION_FILE):
            try:
                os.remove(SESSION_FILE)
                #print(f"[OK] Session supprimée : {SESSION_FILE}")
            except Exception as e:
                print(f"[WARN] Impossible de supprimer la session : {e}")
        sys.exit()
    # Type de licence
    is_trial = lic.get("license_type", "").lower() == "trial"
    os.makedirs(TARGET_DIR, exist_ok=True)

    for fname in os.listdir(CACHE_DIR):
        if is_trial and fname == SECURE_NAME:
            #print(f"[INFO] {fname} ignoré (version d'essai)")
            continue

        src = os.path.join(CACHE_DIR, fname)
        if not os.path.isfile(src):
            continue

        try:
            with open(src, "rb") as f:
                raw = f.read()
                data = base64.b64decode(raw)
        except Exception as e:
            print(f"[WARN] Échec décodage {fname}: {e}")
            continue

        dst = os.path.join(TARGET_DIR, fname)
        with open(dst, "wb") as out:
            out.write(data)
        #print(f"[OK] Fichier décodé : {fname}")

    # Vérification si on doit copier le fichier sécurisé
    if not is_trial:
        secure_dll = os.path.join(SECURE_DIR, SECURE_NAME)
        target_dll = os.path.join(TARGET_DIR, SECURE_NAME)

        if not os.path.exists(target_dll):
            if os.path.exists(secure_dll):
                with open(secure_dll, "rb") as src, open(target_dll, "wb") as dst:
                    dst.write(src.read())
                #print(f"[OK] Copie de {SECURE_NAME} depuis le dossier sécurisé.")
            #else:
                #print(f"[ERROR] Fichier sécurisé manquant : {secure_dll}")