import os
import sys
import ctypes
import time
import importlib
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout, QHBoxLayout, QProgressBar
from PyQt5.QtGui import QPixmap, QFont, QPainter, QLinearGradient, QColor, QBrush
from PyQt5.QtCore import Qt, QObject, QThread, pyqtSignal, QTimer

# --- Gestion du BASE_DIR ---
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
import threading
from multiprocessing import Process
# Tentative d'import modules métier
try:
    from lib import storage
    from lib import hardware_info
    from lib import license_crypto
except Exception:
    storage = None
    hardware_info = None
    license_crypto = None

# Importer la fenêtre d'activation
try:
    from Kelasi import ClientLicenseApp
except Exception:
    ClientLicenseApp = None

# --- Splash Screen ---
class SplashScreen(QWidget):
    def __init__(self, width=460, height=320):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setFixedSize(width, height)

        # Dégradé de fond
        self.bg = QPixmap(self.size())
        painter = QPainter(self.bg)
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(199, 21, 133))
        gradient.setColorAt(1, QColor(99, 11, 93))
        painter.fillRect(self.rect(), QBrush(gradient))
        painter.end()

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(8)

        # Logo + texte
        top_layout = QHBoxLayout()
        logo = QLabel()
        logo_path = os.path.join(BASE_DIR, "ndkasdem", "riseloma", "Bilili", "kelasi.png")
        if os.path.exists(logo_path):
            logo.setPixmap(QPixmap(logo_path).scaled(64, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        text_box = QVBoxLayout()
        title = QLabel("SEVEN 5")
        title.setFont(QFont("Arial Black", 18, QFont.Bold))
        title.setStyleSheet("color: navy;")
        subtitle = QLabel("KELASI")
        subtitle.setFont(QFont("Arial", 20))
        subtitle.setStyleSheet("color: white;")
        text_box.addWidget(title)
        text_box.addWidget(subtitle)
        top_layout.addWidget(logo)
        top_layout.addLayout(text_box)
        top_layout.addStretch()
        main_layout.addLayout(top_layout)

        # Slogan
        slogan = QLabel("Gérez votre école comme pas au par avant.")
        slogan.setFont(QFont("Arial", 10))
        slogan.setStyleSheet("color: silver;")
        main_layout.addWidget(slogan, alignment=Qt.AlignLeft)

        main_layout.addStretch()

        # Centre label
        self.center_label = QLabel("Préparation...")
        self.center_label.setFont(QFont("Arial", 14, QFont.Bold))
        self.center_label.setStyleSheet("color: white;")
        main_layout.addWidget(self.center_label, alignment=Qt.AlignCenter)
        main_layout.addStretch()

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFixedHeight(18)
        self.progress_bar.setStyleSheet("""
            QProgressBar { border: 1px solid #ddd; text-align: center; color: black; }
            QProgressBar::chunk { border-radius: 9px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #5bc0de, stop:1 #0275d8); }
        """)
        main_layout.addWidget(self.progress_bar)

        self.status_label = QLabel("Démarrage...")
        self.status_label.setStyleSheet("color: white; padding-top:6px;")
        main_layout.addWidget(self.status_label)

        # Log
        self.log_label = QLabel("")
        self.log_label.setStyleSheet("color: #ffd1e9; font-size: 10px;")
        self.log_label.setFixedHeight(20)
        main_layout.addWidget(self.log_label)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawPixmap(self.rect(), self.bg)

    def update_progress(self, percent: int, message: str = ""):
        self.progress_bar.setValue(percent)
        if message:
            self.status_label.setText(message)
            self.log_label.setText(message if len(message) < 60 else message[:57] + "...")

# --- Thread de vérification de licence ---
class LicenseWorker(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(int, str)

    def run(self):
        try:
            for i in range(0, 101, 10):
                self.progress.emit(i, f"Initialisation... {i}%")
                time.sleep(0.8)  # Simuler une opération longue
                
                
            # Ici : mettre la vérification réelle
        except Exception as e:
            self.progress.emit(100, f"Erreur: {str(e)}")
        self.finished.emit()


def elevate_for_setup():
    """Relance CE MÊME EXE en admin, avec --setup-task."""
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas",
        sys.executable,
        None,
        None, 1
    )
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False
def run_mainApp():
    try:
        if not is_admin():
            print("lancé sans admin")
            elevate_for_setup()
            sys.exit()
        print("lancé avec admin")
        app = QApplication(sys.argv)
        win = ClientLicenseApp()
        win.show()
        sys.exit(app.exec_())
    except Exception as e:
        pass
def main():
    app = QApplication(sys.argv)
    splash = SplashScreen()
    splash.show()
    # Thread de licence
    worker = LicenseWorker()
    thread = QThread()
    worker.moveToThread(thread)
    worker.progress.connect(splash.update_progress)
    worker.finished.connect(thread.quit)
    worker.finished.connect(lambda: print("Licence vérifiée"))
    thread.started.connect(worker.run)
    
    thread.start()

    # Timer pour fermer le splash après 10 secondes
    def close_splash():
        splash.close()
    QTimer.singleShot(10000, close_splash)  # 10000ms = 10s

    sys.exit(app.exec_())

if __name__ == "__main__":
    t1 = threading.Thread(target=run_mainApp)
    t2 = threading.Thread(target=main)
    
    t1.start()
    t2.start()
